import { createAction, props } from '@ngrx/store';
import { Player } from '../utils/player';

export const CREATE_PLAYER = '[ADD PLAYER] CREATE_PLAYER';

export const ADD_PLAYER = createAction(CREATE_PLAYER, props<{payload: Player}>());

