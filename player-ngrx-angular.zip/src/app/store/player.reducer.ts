import {ADD_PLAYER} from './player.actions';
import { createReducer, on } from '@ngrx/store';

export const initialState = [
  {
    name: 'Vikram',
    country: 'India',
    category: 'Batter',
    image:
      'https://akm-img-a-in.tosshub.com/indiatoday/images/story/202210/viratkohliindvpakt20wc-sixteen_nine.jpg?VersionId=zN5Gqwdv6SNOESeBBWj359Yq5f4uqcxX&size=690:388',
  },
];

export const playersReducer = createReducer(
  initialState,
  on(ADD_PLAYER, (state, {payload}) =>  [...state, payload])
);

