import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { StoreModule } from '@ngrx/store';
import { ViewPlayersComponent } from './view-players/view-players.component';
import { PlayersComponent } from './players/players.component';
import { AddPlayerComponent } from './add-player/add-player.component';
import { FormsModule } from '@angular/forms';
import { playersReducer } from './store/player.reducer';

@NgModule({
  declarations: [
    AppComponent,
    ViewPlayersComponent,
    PlayersComponent,
    AddPlayerComponent
  ],
  imports: [
    BrowserModule,
    NgbModule,
    FormsModule,
    StoreModule.forRoot({ playerList: playersReducer})],

  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
