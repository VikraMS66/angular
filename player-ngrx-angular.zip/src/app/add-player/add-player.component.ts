import { Component, OnInit } from '@angular/core';
import { Player } from '../utils/player';
import { Store } from '@ngrx/store';
import { ADD_PLAYER } from '../store/player.actions';

@Component({
  selector: 'app-add-player',
  templateUrl: './add-player.component.html',
  styleUrls: ['./add-player.component.css'],
})
export class AddPlayerComponent implements OnInit {
  player: Player;

  constructor(private store: Store<{ playerList: Player[]}>) {}

  ngOnInit(): void {
    this.player = {
      name: '',
      country: '',
      category: '',
      image: '',
    };
  }

  addPlayer() {
    this.store.dispatch(ADD_PLAYER({ payload: this.player }));
  }
}
