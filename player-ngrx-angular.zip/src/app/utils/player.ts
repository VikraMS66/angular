export class Player {
    name: string;
    country: string;
    category: string;
    image: string;
}