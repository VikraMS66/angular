import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Player } from '../utils/player';

@Component({
  selector: 'app-view-players',
  templateUrl: './view-players.component.html',
  styleUrls: ['./view-players.component.css'],
})
export class ViewPlayersComponent implements OnInit {

  players: Observable<Player[]>;

  constructor(private store: Store<{playerList: Player[]}>) {}

  ngOnInit(): void {
    this.players = this.store.select('playerList');
  }

}
