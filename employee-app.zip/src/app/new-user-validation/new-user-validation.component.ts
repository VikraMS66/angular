import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { EmployeeService } from '../service/employee.service';
import { EmailValidator } from '../shared/email-validator';
import { Validation } from '../shared/validation';


@Component({
  selector: 'app-new-user-validation',
  templateUrl: './new-user-validation.component.html',
  styleUrls: ['./new-user-validation.component.css']
})
export class NewUserValidationComponent implements OnInit {

  constructor(private fb: FormBuilder, private service: EmployeeService) { }

  ngOnInit(): void {
  }

  //------------to be done - apply and try, find a way to do same feature with form group
  // myForm = this.fb.group({
  //   username: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(10)]],
  //   email: ['', Validators.required, Validators.email],
  //   password: ['', Validators.required, Validators.minLength(6), Validators.maxLength(20)],
  //   confirmPassword: ['', Validators.required, Validators.minLength(6), Validators.maxLength(20)],
  // },
  // [Validation.MatchValidator('password', 'confirmPassword')]
  
  // )

  emailValidation = new EmailValidator(this.service);
  myForm = new FormGroup(
    {
      username: new FormControl('',[Validators.required, Validators.minLength(4), Validators.maxLength(10)]),
      email: new FormControl('',{
          validators: [Validators.required, Validators.email],
          asyncValidators: [this.emailValidation.uniqueEmailValidator()]
      }),
      password: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(20)]),
      confirmPassword: new FormControl('', [Validators.required]),
  },
  [Validation.MatchValidator('password', 'confirmPassword')]
  )

  get username() {
    return this.myForm.get('username') as FormControl;
  }

  get email() {
    return this.myForm.get('email') as FormControl;
  }

  get password() {
    return this.myForm.get('password') as FormControl;
  }

  get confirmPassword() {
    return this.myForm.get('confirmPassword') as FormControl;
  }

  get passwordMatchError() {
    return (
      this.myForm.getError('mismatch') && (this.myForm.get('confirmPassword')?.touched || this.myForm.get('confirmPassword')?.dirty)
    );
  }

}
