import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewUserValidationComponent } from './new-user-validation.component';

describe('NewUserValidationComponent', () => {
  let component: NewUserValidationComponent;
  let fixture: ComponentFixture<NewUserValidationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewUserValidationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NewUserValidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
