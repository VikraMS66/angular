import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from '../utils/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  baseUrl = 'http://localhost:8080/tm';

  constructor(private http: HttpClient) { }
  
  getEmployees() {
    return this.http.get(`${this.baseUrl}/employees`);
  }

  addEmployee(body: Employee) {
    return this.http.post(`${this.baseUrl}/new`, body);
  }



}