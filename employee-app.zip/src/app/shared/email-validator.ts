import { EmployeeService } from "../service/employee.service";
import { AbstractControl, AsyncValidatorFn, FormControl, ValidationErrors } from "@angular/forms";
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators'

export class EmailValidator {
    employees: any[];
    
    empEmailList: string[];

    constructor(private empService: EmployeeService) {
        this.empEmailList = [];
        this.empService.getEmployees().subscribe((res: any) => {
            res.forEach((e: any) => {
                this.empEmailList.push(e.email);
            })
        });
    }

    emailExists(email: string) {
        return of(email).pipe(
            map((email: string) => {
                return this.empEmailList.includes(email);
            })
        )
    }

    uniqueEmailValidator(): AsyncValidatorFn {
        return (control: AbstractControl): Observable<ValidationErrors | null> => { 
           return this.emailExists(control.value).pipe(
            map(exists => (exists ? { emailExists: true } : null))
           )
        }
    }

}
