import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { EmployeeService } from '../service/employee.service';
import { Employee } from '../utils/employee';

@Component({
  selector: 'app-employee-form',
  templateUrl: './employee-form.component.html',
  styleUrls: ['./employee-form.component.css']
})
export class EmployeeFormComponent implements OnInit {
   
     employee: Employee;

      // myForm = new FormGroup( {
      //   name : new FormControl('', {
      //     validators: [ Validators.required, Validators.minLength(4), Validators.maxLength(20) ],
      //   }),
    
      //   email : new FormControl('', {
      //     validators: [Validators.required, Validators.email],
      //     asyncValidators: []
      //   }),
    
      //   age : new FormControl(null, {
      //     validators: [Validators.required, Validators.min(15), Validators.max(30), Validators.maxLength(2)],
      //   }),
    
      //   salary : new FormControl(null, {
      //     validators: [Validators.required, Validators.min(100000), Validators.max(1000000), Validators.maxLength(7)]
      //   }),
      // });

      myForm = this.fb.group({
        name: ['', [Validators.required, Validators.minLength(4), Validators.pattern('^[a-zA-Z ]*$'), Validators.maxLength(20)]],
        email: ['', [Validators.required, Validators.email]],
        age: ['', [Validators.required, Validators.min(15), Validators.max(30), Validators.maxLength(2), Validators.pattern('^[0-9]*$')]],
        salary: ['', [Validators.required, Validators.min(100000), Validators.pattern('^[0-9]*$'), Validators.max(1000000), Validators.maxLength(7)]]
      });
  
  constructor(private empService: EmployeeService, private fb: FormBuilder) { }

  ngOnInit(): void {
     
  }

  get name() {
    return this.myForm.get('name') as FormControl;
  }

  get email() {
    return this.myForm.get('email') as FormControl;
  }

  get age() {
    return this.myForm.get('age') as FormControl;
  }

  get salary() {
    return this.myForm.get('salary') as FormControl;
  }

  addEmployee() {
    this.employee = {
      name: this.name.value,
      email: this.email.value,
      age: this.age.value,
      salary: this.salary.value
    }

    this.empService.addEmployee(this.employee).subscribe((res) => {
         console.log(res);
    });
  }
}
