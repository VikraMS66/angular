import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-array-form',
  templateUrl: './array-form.component.html',
  styleUrls: ['./array-form.component.css']
})
export class ArrayFormComponent implements OnInit {

  myForm: FormGroup;

   phone = this.fb.group( {
    prefix: ['', [Validators.required, Validators.maxLength(3)]],
    number: ['', [Validators.required, Validators.pattern('[0-9]+'), Validators.minLength(5), Validators.maxLength(15)]],
  })

  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.myForm = this.fb.group( {
      email: ['', [Validators.required, Validators.email]],
      phones: this.fb.array([])
    })

  }

  get phones() {
    return this.myForm.get('phones') as FormArray;
  }

  get email() {
    return this.myForm.get('email') as FormControl;
  }

  get prefix() {
    return this.phone.get('prefix') as FormControl;
  }

  get number() {
    return this.phone.get('number') as FormControl;
  }

  addPhone() {
    this.phones.push(this.phone);
  }

  savePhone(p: HTMLInputElement, n: HTMLInputElement) {
    p.disabled = true;
    n.disabled = true;
  }

  deletePhone(i: any) {
    this.phones.removeAt(i);
  }

}
