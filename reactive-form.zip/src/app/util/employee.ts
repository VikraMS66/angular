export class Employee {
    name: string;
    email: string;
    age: number;
    salary: number;
}
