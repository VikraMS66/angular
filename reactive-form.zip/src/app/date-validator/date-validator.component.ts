import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { DateValidator } from '../shared/date-validator';

@Component({
  selector: 'app-date-validator',
  templateUrl: './date-validator.component.html',
  styleUrls: ['./date-validator.component.css']
})
export class DateValidatorComponent implements OnInit {
  heroForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.heroForm = this.fb.group({
      date: ['', Validators.compose([Validators.required, DateValidator.dateVaidator])]
    });
  }

  get date() {
    return this.heroForm.get('date') as FormControl;
  }

  ngOnInit() {
  }

  submit() {
    //console.log(this.heroForm.valid);
  }
}