import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { DateValidator } from '../shared/date-validator';
import { Movie } from '../utils/movie';

@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css'],
})
export class AddMovieComponent implements OnInit {
  @Output() addMovieEvent = new EventEmitter<Movie>();

  movie: Movie;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.movie = {
      name: '',
      genre: '',
      rating: 1,
      relDate: '',
      thumb: '',
    };
  }

  form = this.fb.group({
    name: [
      '',
      [
        Validators.required,
        Validators.maxLength(20),
        Validators.pattern('^[a-zA-Z0-9_ ]*$'),
      ],
    ],
    genre: [
      '',
      [
        Validators.required,
        Validators.maxLength(20),
        Validators.pattern('^[a-zA-Z ]*$'),
      ],
    ],
    thumb: [
      '',
      [
        Validators.required,
      ],
    ],
    rating: [
      null,
      [
        Validators.required,
        Validators.min(1),
        Validators.max(10),
        Validators.pattern('^[0-9]*$'),
        Validators.maxLength(2),
      ],
    ],
    date: [
      '',
      Validators.compose([Validators.required, DateValidator.dateVaidator]),
    ],
  });

  get name() {
    return this.form.get('name') as FormControl;
  }

  get genre() {
    return this.form.get('genre') as FormControl;
  }

  get thumb() {
    return this.form.get('thumb') as FormControl;
  }

  get rating() {
    return this.form.get('rating') as FormControl;
  }

  get date() {
    return this.form.get('date') as FormControl;
  }

  addMovie() {
    this.addMovieEvent.emit(this.movie);
    //(document.getElementById("myForm") as HTMLFormElement).reset();
    // this.movie = {
    //   name: '',
    //   genre: '',
    //   rating: 1,
    //   relDate: new Date(),
    //   thumb: ''
    // };

  }
}
