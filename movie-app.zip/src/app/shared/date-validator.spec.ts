import { DateValidator } from './date-validator';

describe('DateValidator', () => {
  it('should create an instance', () => {
    expect(new DateValidator()).toBeTruthy();
  });
});
