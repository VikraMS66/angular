import { Component, OnInit } from '@angular/core';
import { Movie } from '../utils/movie';

@Component({
  selector: 'app-movie-home',
  templateUrl: './movie-home.component.html',
  styleUrls: ['./movie-home.component.css']
})
export class MovieHomeComponent implements OnInit {

  movieList: Movie[] = [];
  selectedMovie: Movie;

  relatedMovies: Movie[] = [];

  constructor() { }

  ngOnInit(): void {
    
  }

  addMovie($event:any) {
    // console.log($event);
    this.movieList.push($event);
    console.table(this.movieList);
    this.setMovie($event);
  }

  setMovie($event:any) {
    // console.log($event);
    this.selectedMovie = $event;
    // console.log(this.selectedMovie);
    this.setRelatedMovie();

  }

  setRelatedMovie() {
    const date = new Date(this.selectedMovie.relDate);
    const month = (date.getDate()) === 1 ? date.getMonth() : (date.getMonth() + 1);
    
    this.relatedMovies = this.movieList.filter((m) => {
      if(this.selectedMovie !== m) {
        return (new Date(m.relDate).getMonth() + 1) === month;
      } else {
        return;
      }
    })
  }

}
