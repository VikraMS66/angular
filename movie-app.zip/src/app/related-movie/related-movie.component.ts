import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Movie } from '../utils/movie';

@Component({
  selector: 'app-related-movie',
  templateUrl: './related-movie.component.html',
  styleUrls: ['./related-movie.component.css']
})
export class RelatedMovieComponent implements OnInit {

  @Input() relatedMovieList: Movie[];
  constructor() { }

  ngOnInit(): void {
  }

  @Output() selectedMovieEmit = new EventEmitter<Movie>();

  selectedMovie(movie: Movie) {
    this.selectedMovieEmit.emit(movie);
  }

}
