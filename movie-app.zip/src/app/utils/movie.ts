export class Movie {
    name: string;
    relDate: string;
    rating: number;
    genre: string;
    thumb: string;
}
