import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Movie } from '../utils/movie';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.css'],
})
export class MovieListComponent implements OnInit {
  @Input() movieList: Movie[];

  constructor() {}

  ngOnInit(): void {}

  @Output() selectedMovieEmit = new EventEmitter<Movie>();

  selectedMovie(movie: Movie) {
    this.selectedMovieEmit.emit(movie);
  }
}
